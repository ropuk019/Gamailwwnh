import Phaser from 'phaser';
import { createButton } from '../utils/ui.js';

export class MenuScene extends Phaser.Scene {
  constructor() {
    super({ key: 'MenuScene' });
  }

  create() {
    // Background elements
    const bg = this.add.image(0, 0, 'background').setOrigin(0, 0);
    bg.displayWidth = this.sys.game.config.width;
    bg.displayHeight = this.sys.game.config.height;
    
    // Parallax buildings
    const buildings = this.add.tileSprite(0, this.sys.game.config.height - 300, 
      this.sys.game.config.width, 300, 'buildings').setOrigin(0, 0);
    
    // Game logo
    const logo = this.add.image(this.sys.game.config.width / 2, 150, 'logo-game');
    logo.setScale(0.8);
    
    // Add menu buttons
    this.createMenuButtons();
    
    // Play menu music
    if (this.registry.get('musicEnabled')) {
      this.menuMusic = this.sound.add('music-menu', { 
        loop: true,
        volume: 0.7
      });
      this.menuMusic.play();
    }
    
    // Add animated character
    this.addAnimatedCharacter();
    
    // Add version text
    this.add.text(10, this.sys.game.config.height - 30, 'v1.0.0', {
      fontFamily: 'Poppins',
      fontSize: '14px',
      color: '#333'
    });
    
    // Start buildings animation
    this.tweens.add({
      targets: buildings,
      tilePositionX: '+=500',
      ease: 'Linear',
      duration: 10000,
      repeat: -1
    });
  }

  createMenuButtons() {
    const buttonConfig = {
      scene: this,
      width: 200,
      height: 60,
      fontFamily: 'Poppins',
      fontSize: 24,
      sound: 'sfx-button'
    };
    
    // Calculate button positions
    const centerX = this.sys.game.config.width / 2;
    const startY = 280;
    const spacing = 70;
    
    // Start Game button
    createButton({
      ...buttonConfig,
      x: centerX,
      y: startY,
      text: 'Start Game',
      texture: 'btn-start',
      callback: () => this.startGame()
    });
    
    // Settings button
    createButton({
      ...buttonConfig,
      x: centerX,
      y: startY + spacing,
      text: 'Settings',
      texture: 'btn-settings',
      callback: () => this.openSettings()
    });
    
    // Leaderboard button
    createButton({
      ...buttonConfig,
      x: centerX,
      y: startY + spacing * 2,
      text: 'Leaderboard',
      texture: 'btn-leaderboard',
      callback: () => this.openLeaderboard()
    });
    
    // Missions button
    createButton({
      ...buttonConfig,
      x: centerX,
      y: startY + spacing * 3,
      text: 'Missions',
      texture: 'btn-missions',
      callback: () => this.openMissions()
    });
    
    // Character/Skins button
    createButton({
      ...buttonConfig,
      x: centerX,
      y: startY + spacing * 4,
      text: 'Character',
      texture: 'btn-character',
      callback: () => this.openCharacter()
    });
  }

  addAnimatedCharacter() {
    const player = this.add.sprite(150, this.sys.game.config.height - 150, 'player');
    player.setScale(1.2);
    player.play('run');
    
    // Add idle animation
    this.tweens.add({
      targets: player,
      y: player.y - 10,
      duration: 1000,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut'
    });
  }

  startGame() {
    if (this.menuMusic) {
      this.menuMusic.stop();
    }
    this.scene.start('GameScene');
  }

  openSettings() {
    this.scene.launch('SettingsScene');
    this.scene.pause();
  }

  openLeaderboard() {
    this.scene.launch('LeaderboardScene');
    this.scene.pause();
  }

  openMissions() {
    this.scene.launch('MissionsScene');
    this.scene.pause();
  }

  openCharacter() {
    this.scene.launch('CharacterScene');
    this.scene.pause();
  }
}