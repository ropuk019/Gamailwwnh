import Phaser from 'phaser';
import { Player } from '../entities/Player.js';
import { ObstacleManager } from '../managers/ObstacleManager.js';
import { PowerUpManager } from '../managers/PowerUpManager.js';
import { ScoreManager } from '../managers/ScoreManager.js';
import { BackgroundManager } from '../managers/BackgroundManager.js';

export class GameScene extends Phaser.Scene {
  constructor() {
    super({ key: 'GameScene' });
  }

  init() {
    this.speed = 500;
    this.minSpeed = 500;
    this.maxSpeed = 1200;
    this.speedIncrement = 1;
    this.distance = 0;
    this.isGameRunning = false;
    this.isPaused = false;
  }

  create() {
    // Create background elements
    this.backgroundManager = new BackgroundManager(this);
    
    // Create ground
    this.createGround();
    
    // Create player
    this.player = new Player(this, 200, this.sys.game.config.height - 150);
    
    // Set up obstacle manager
    this.obstacleManager = new ObstacleManager(this);
    
    // Set up power-up manager
    this.powerUpManager = new PowerUpManager(this);
    
    // Set up score manager
    this.scoreManager = new ScoreManager(this);
    
    // Start UI scene
    this.scene.launch('UIScene');
    this.scene.get('UIScene').events.on('resume_game', this.resumeGame, this);
    this.scene.get('UIScene').events.on('exit_to_menu', this.exitToMenu, this);
    
    // Set up collision detection
    this.setUpCollisions();
    
    // Set up input handlers
    this.setUpInputHandlers();
    
    // Start background music
    if (this.registry.get('musicEnabled')) {
      this.music = this.sound.add('music-game', { 
        loop: true,
        volume: 0.5
      });
      this.music.play();
    }
    
    // Start the game
    this.startGame();
    
    // Setup game timer for distance tracking
    this.gameTimer = this.time.addEvent({
      delay: 100,
      callback: this.updateGame,
      callbackScope: this,
      loop: true
    });
  }

  update() {
    if (!this.isGameRunning) return;
    
    // Update managers
    this.backgroundManager.update(this.speed);
    this.obstacleManager.update(this.speed);
    this.powerUpManager.update(this.speed);
    
    // Update player
    this.player.update();
    
    // Increase game speed over time
    this.speed = Math.min(this.maxSpeed, this.speed + this.speedIncrement * this.game.loop.delta * 0.01);
  }

  createGround() {
    // Create ground physics group
    this.groundGroup = this.physics.add.staticGroup();
    
    // Calculate how many ground tiles we need to cover the screen width
    const groundWidth = this.textures.get('ground').getSourceImage().width;
    const tilesNeeded = Math.ceil(this.sys.game.config.width / groundWidth) + 1;
    
    // Create the ground tiles
    for (let i = 0; i < tilesNeeded; i++) {
      const ground = this.groundGroup.create(
        i * groundWidth,
        this.sys.game.config.height - 40,
        'ground'
      );
      ground.setOrigin(0, 0.5);
      ground.setImmovable(true);
      ground.displayWidth = groundWidth;
    }
    
    // Add a physics body for the entire ground
    this.groundCollider = this.physics.add.collider(
      this.player.sprite,
      this.groundGroup,
      this.handleGroundCollision,
      null,
      this
    );
  }

  setUpCollisions() {
    // Set up collision between player and obstacles
    this.physics.add.overlap(
      this.player.sprite,
      this.obstacleManager.obstaclesGroup,
      this.handleObstacleCollision,
      null,
      this
    );
    
    // Set up collision between player and power-ups
    this.physics.add.overlap(
      this.player.sprite,
      this.powerUpManager.powerUpsGroup,
      this.handlePowerUpCollision,
      null,
      this
    );
  }

  setUpInputHandlers() {
    // Keyboard controls
    this.cursors = this.input.keyboard.createCursorKeys();
    this.spacebar = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    
    // Mobile controls
    this.input.on('pointerdown', (pointer) => {
      if (!this.isGameRunning || this.isPaused) return;
      
      // Store initial touch position
      this.touchStartY = pointer.y;
    });
    
    this.input.on('pointerup', (pointer) => {
      if (!this.isGameRunning || this.isPaused) return;
      
      const touchEndY = pointer.y;
      const touchDuration = pointer.upTime - pointer.downTime;
      
      // Check for swipe down (slide)
      if (this.touchStartY && touchEndY - this.touchStartY > 50) {
        this.player.slide();
      } 
      // Check for tap (jump)
      else if (touchDuration < 200) {
        this.player.jump();
      }
      
      // Reset touch start position
      this.touchStartY = null;
    });
  }

  handleGroundCollision() {
    if (this.player.isJumping) {
      this.player.isJumping = false;
      this.player.canJump = true;
    }
  }

  handleObstacleCollision(playerSprite, obstacle) {
    // Skip collision if player is invincible
    if (this.player.isInvincible) return;
    
    // Play collision sound
    if (this.registry.get('soundEnabled')) {
      this.sound.play('sfx-collision');
    }
    
    // Check if player has extra life
    if (this.player.lives > 1) {
      this.player.loseLife();
      this.player.becomeInvincible(1500);
      obstacle.destroy();
    } else {
      // Game over
      this.gameOver();
    }
  }

  handlePowerUpCollision(playerSprite, powerUp) {
    // Apply power-up effect
    this.powerUpManager.applyPowerUp(powerUp.texture.key);
    
    // Play power-up sound
    if (this.registry.get('soundEnabled')) {
      this.sound.play('sfx-powerup');
    }
    
    // Destroy the power-up
    powerUp.destroy();
  }

  startGame() {
    this.isGameRunning = true;
    this.speed = this.minSpeed;
    this.distance = 0;
    this.scoreManager.resetScore();
    this.player.reset();
    
    // Reset managers
    this.obstacleManager.start();
    this.powerUpManager.start();
    
    // Update UI
    this.events.emit('game_started');
  }

  pauseGame() {
    if (!this.isGameRunning) return;
    
    this.isPaused = true;
    this.physics.pause();
    this.gameTimer.paused = true;
    
    if (this.music) {
      this.music.pause();
    }
    
    // Notify UI
    this.events.emit('game_paused');
  }

  resumeGame() {
    if (!this.isGameRunning || !this.isPaused) return;
    
    this.isPaused = false;
    this.physics.resume();
    this.gameTimer.paused = false;
    
    if (this.music) {
      this.music.resume();
    }
    
    // Notify UI
    this.events.emit('game_resumed');
  }

  gameOver() {
    this.isGameRunning = false;
    this.physics.pause();
    this.gameTimer.paused = true;
    
    // Play game over sound
    if (this.registry.get('soundEnabled')) {
      this.sound.play('sfx-gameover');
    }
    
    if (this.music) {
      this.music.stop();
    }
    
    // Update high score if needed
    const gameData = this.registry.get('gameData');
    if (this.scoreManager.score > gameData.highScore) {
      gameData.highScore = this.scoreManager.score;
      this.registry.set('gameData', gameData);
      localStorage.setItem('sheikhhashinarunner_data', JSON.stringify(gameData));
    }
    
    // Show game over scene
    this.scene.pause();
    this.scene.launch('GameOverScene', { 
      score: this.scoreManager.score, 
      distance: this.distance 
    });
  }

  exitToMenu() {
    if (this.music) {
      this.music.stop();
    }
    
    this.scene.stop('UIScene');
    this.scene.start('MenuScene');
  }

  updateGame() {
    if (!this.isGameRunning || this.isPaused) return;
    
    // Update distance
    this.distance += 0.1;
    
    // Update mission progress
    this.updateMissionProgress();
    
    // Emit distance update event
    this.events.emit('distance_updated', Math.floor(this.distance));
  }

  updateMissionProgress() {
    const gameData = this.registry.get('gameData');
    
    // Update distance mission
    const distanceMission = gameData.missions.daily.find(m => m.type === 'distance');
    if (distanceMission && !distanceMission.completed) {
      distanceMission.progress = Math.max(distanceMission.progress, Math.floor(this.distance));
      if (distanceMission.progress >= distanceMission.target) {
        distanceMission.completed = true;
      }
    }
    
    // Update score mission
    const scoreMission = gameData.missions.daily.find(m => m.type === 'score');
    if (scoreMission && !scoreMission.completed) {
      scoreMission.progress = Math.max(scoreMission.progress, this.scoreManager.score);
      if (scoreMission.progress >= scoreMission.target) {
        scoreMission.completed = true;
      }
    }
    
    // Save updated mission progress
    this.registry.set('gameData', gameData);
    localStorage.setItem('sheikhhashinarunner_data', JSON.stringify(gameData));
  }
}