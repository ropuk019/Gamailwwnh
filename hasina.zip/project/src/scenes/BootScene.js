import Phaser from 'phaser';

export class BootScene extends Phaser.Scene {
  constructor() {
    super({ key: 'BootScene' });
  }

  preload() {
    // Load minimal assets needed for the loading screen
    this.load.image('logo', 'assets/ui/logo.png');
    this.load.image('loading-bg', 'assets/ui/loading-bg.png');
  }

  create() {
    // Initialize game data
    this.initializeGameData();
    
    // Set up sound preferences
    this.setupSoundPreferences();
    
    // Transition to the preload scene
    this.scene.start('PreloadScene');
  }

  initializeGameData() {
    // Initialize game data structure if not already present
    if (!localStorage.getItem('sheikhhashinarunner_data')) {
      const gameData = {
        highScore: 0,
        coins: 0,
        unlockedSkins: ['default'],
        currentSkin: 'default',
        settings: {
          music: true,
          sound: true,
          language: 'bn' // 'bn' for Bengali, 'en' for English
        },
        missions: {
          daily: [
            { id: 'run30', type: 'distance', target: 30, progress: 0, completed: false, reward: 50 },
            { id: 'collect5', type: 'collect', target: 5, progress: 0, completed: false, reward: 30 },
            { id: 'score50', type: 'score', target: 50, progress: 0, completed: false, reward: 40 }
          ],
          refreshDate: new Date().toDateString()
        }
      };
      
      localStorage.setItem('sheikhhashinarunner_data', JSON.stringify(gameData));
    } else {
      // Check if daily missions need refresh
      const gameData = JSON.parse(localStorage.getItem('sheikhhashinarunner_data'));
      const today = new Date().toDateString();
      
      if (gameData.missions.refreshDate !== today) {
        gameData.missions.daily = [
          { id: 'run30', type: 'distance', target: 30, progress: 0, completed: false, reward: 50 },
          { id: 'collect5', type: 'collect', target: 5, progress: 0, completed: false, reward: 30 },
          { id: 'score50', type: 'score', target: 50, progress: 0, completed: false, reward: 40 }
        ];
        gameData.missions.refreshDate = today;
        localStorage.setItem('sheikhhashinarunner_data', JSON.stringify(gameData));
      }
    }
    
    // Make game data available to all scenes
    this.registry.set('gameData', JSON.parse(localStorage.getItem('sheikhhashinarunner_data')));
  }

  setupSoundPreferences() {
    const gameData = this.registry.get('gameData');
    this.registry.set('musicEnabled', gameData.settings.music);
    this.registry.set('soundEnabled', gameData.settings.sound);
  }
}