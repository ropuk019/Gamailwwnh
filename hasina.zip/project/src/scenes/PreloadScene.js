import Phaser from 'phaser';

export class PreloadScene extends Phaser.Scene {
  constructor() {
    super({ key: 'PreloadScene' });
  }

  preload() {
    this.createLoadingUI();
    
    // Character sprites
    this.load.spritesheet('player', 'assets/characters/hasina_spritesheet.png', {
      frameWidth: 128,
      frameHeight: 128
    });
    
    this.load.spritesheet('player-slide', 'assets/characters/hasina_slide_spritesheet.png', {
      frameWidth: 128,
      frameHeight: 128
    });
    
    // Obstacles
    this.load.image('obstacle-files', 'assets/obstacles/corruption_files.png');
    this.load.image('obstacle-crowd', 'assets/obstacles/protestors.png');
    this.load.image('obstacle-drone', 'assets/obstacles/fake_news_drone.png');
    this.load.image('obstacle-camera', 'assets/obstacles/media_camera.png');
    this.load.image('obstacle-screen', 'assets/obstacles/fake_news_screen.png');
    
    // Power-ups
    this.load.image('powerup-scroll', 'assets/powerups/constitution_scroll.png');
    this.load.image('powerup-flag', 'assets/powerups/national_flag.png');
    this.load.image('powerup-support', 'assets/powerups/peoples_support.png');
    
    // Environment
    this.load.image('ground', 'assets/environment/ground.png');
    this.load.image('background', 'assets/environment/background.png');
    this.load.image('buildings', 'assets/environment/buildings.png');
    this.load.image('trees', 'assets/environment/trees.png');
    
    // UI
    this.load.image('logo-game', 'assets/ui/game_logo.png');
    this.load.image('btn-start', 'assets/ui/btn_start.png');
    this.load.image('btn-settings', 'assets/ui/btn_settings.png');
    this.load.image('btn-leaderboard', 'assets/ui/btn_leaderboard.png');
    this.load.image('btn-missions', 'assets/ui/btn_missions.png');
    this.load.image('btn-character', 'assets/ui/btn_character.png');
    this.load.image('btn-retry', 'assets/ui/btn_retry.png');
    this.load.image('btn-home', 'assets/ui/btn_home.png');
    this.load.image('btn-share', 'assets/ui/btn_share.png');
    this.load.image('btn-sound-on', 'assets/ui/btn_sound_on.png');
    this.load.image('btn-sound-off', 'assets/ui/btn_sound_off.png');
    this.load.image('btn-music-on', 'assets/ui/btn_music_on.png');
    this.load.image('btn-music-off', 'assets/ui/btn_music_off.png');
    this.load.image('panel', 'assets/ui/panel.png');
    this.load.image('life-icon', 'assets/ui/life_icon.png');
    this.load.image('coin-icon', 'assets/ui/coin_icon.png');
    
    // Audio
    this.load.audio('music-menu', 'assets/audio/menu_music.mp3');
    this.load.audio('music-game', 'assets/audio/game_music.mp3');
    this.load.audio('sfx-jump', 'assets/audio/jump.mp3');
    this.load.audio('sfx-slide', 'assets/audio/slide.mp3');
    this.load.audio('sfx-collision', 'assets/audio/collision.mp3');
    this.load.audio('sfx-powerup', 'assets/audio/powerup.mp3');
    this.load.audio('sfx-gameover', 'assets/audio/game_over.mp3');
    this.load.audio('sfx-button', 'assets/audio/button_click.mp3');
    
    // Font
    this.load.bitmapFont('game-font', 'assets/fonts/font.png', 'assets/fonts/font.xml');
  }

  create() {
    // Create player animations
    this.createAnimations();
    
    // Start the main menu scene
    this.scene.start('MenuScene');
  }

  createLoadingUI() {
    // Create a loading screen with a progress bar
    const width = this.cameras.main.width;
    const height = this.cameras.main.height;
    
    const progressBar = this.add.graphics();
    const progressBox = this.add.graphics();
    progressBox.fillStyle(0x222222, 0.8);
    progressBox.fillRoundedRect(width / 2 - 160, height / 2 - 25, 320, 50, 10);
    
    const loadingText = this.make.text({
      x: width / 2,
      y: height / 2 - 50,
      text: 'Loading...',
      style: {
        font: '20px monospace',
        fill: '#ffffff'
      }
    });
    loadingText.setOrigin(0.5, 0.5);
    
    const percentText = this.make.text({
      x: width / 2,
      y: height / 2,
      text: '0%',
      style: {
        font: '18px monospace',
        fill: '#ffffff'
      }
    });
    percentText.setOrigin(0.5, 0.5);
    
    const assetText = this.make.text({
      x: width / 2,
      y: height / 2 + 50,
      text: '',
      style: {
        font: '18px monospace',
        fill: '#ffffff'
      }
    });
    assetText.setOrigin(0.5, 0.5);
    
    // Add logo
    const logo = this.add.image(width / 2, height / 2 - 100, 'logo');
    logo.setScale(0.5);
    
    // Update progress bar as assets load
    this.load.on('progress', (value) => {
      percentText.setText(parseInt(value * 100) + '%');
      progressBar.clear();
      progressBar.fillStyle(0x00ff00, 1);
      progressBar.fillRoundedRect(width / 2 - 150, height / 2 - 15, 300 * value, 30, 5);
    });
    
    this.load.on('fileprogress', (file) => {
      assetText.setText('Loading asset: ' + file.key);
    });
    
    this.load.on('complete', () => {
      progressBar.destroy();
      progressBox.destroy();
      loadingText.destroy();
      percentText.destroy();
      assetText.destroy();
    });
  }

  createAnimations() {
    // Player run animation
    this.anims.create({
      key: 'run',
      frames: this.anims.generateFrameNumbers('player', { start: 0, end: 7 }),
      frameRate: 12,
      repeat: -1
    });
    
    // Player jump animation
    this.anims.create({
      key: 'jump',
      frames: this.anims.generateFrameNumbers('player', { start: 8, end: 12 }),
      frameRate: 12,
      repeat: 0
    });
    
    // Player slide animation
    this.anims.create({
      key: 'slide',
      frames: this.anims.generateFrameNumbers('player-slide', { start: 0, end: 5 }),
      frameRate: 12,
      repeat: 0
    });
    
    // Player hurt animation
    this.anims.create({
      key: 'hurt',
      frames: this.anims.generateFrameNumbers('player', { start: 13, end: 15 }),
      frameRate: 10,
      repeat: 0
    });
  }
}