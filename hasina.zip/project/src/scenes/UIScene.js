import Phaser from 'phaser';
import { createButton } from '../utils/ui.js';

export class UIScene extends Phaser.Scene {
  constructor() {
    super({ key: 'UIScene' });
  }

  create() {
    // Get reference to the game scene
    this.gameScene = this.scene.get('GameScene');
    
    // Score display
    this.scoreText = this.add.text(20, 20, 'Score: 0', {
      fontFamily: 'Poppins',
      fontSize: '24px',
      color: '#ffffff',
      stroke: '#000000',
      strokeThickness: 4
    });
    
    // Distance display
    this.distanceText = this.add.text(20, 60, 'Distance: 0m', {
      fontFamily: 'Poppins',
      fontSize: '24px',
      color: '#ffffff',
      stroke: '#000000',
      strokeThickness: 4
    });
    
    // Lives display
    this.createLivesDisplay();
    
    // Pause button
    this.createPauseButton();
    
    // Power-up indicator
    this.createPowerUpIndicator();
    
    // Pause menu
    this.createPauseMenu();
    
    // Listen for events from the game scene
    this.gameScene.events.on('score_updated', this.updateScore, this);
    this.gameScene.events.on('distance_updated', this.updateDistance, this);
    this.gameScene.events.on('lives_updated', this.updateLives, this);
    this.gameScene.events.on('powerup_activated', this.showPowerUpEffect, this);
    this.gameScene.events.on('powerup_deactivated', this.hidePowerUpEffect, this);
    this.gameScene.events.on('game_paused', this.showPauseMenu, this);
    this.gameScene.events.on('game_resumed', this.hidePauseMenu, this);
    
    // Make sure pause menu is hidden initially
    this.pauseMenu.setVisible(false);
  }

  createLivesDisplay() {
    this.livesGroup = this.add.group();
    this.updateLives(3); // Start with 3 lives
  }

  createPauseButton() {
    const pauseButton = this.add.image(
      this.sys.game.config.width - 50, 
      50, 
      'btn-settings'
    );
    pauseButton.setScale(0.6);
    pauseButton.setInteractive({ useHandCursor: true });
    
    pauseButton.on('pointerdown', () => {
      if (this.registry.get('soundEnabled')) {
        this.sound.play('sfx-button');
      }
      this.gameScene.pauseGame();
    });
  }

  createPowerUpIndicator() {
    // Create power-up background
    this.powerUpBg = this.add.rectangle(
      this.sys.game.config.width / 2,
      40,
      300,
      50,
      0x000000,
      0.5
    );
    this.powerUpBg.setStrokeStyle(2, 0xffffff);
    this.powerUpBg.setVisible(false);
    
    // Create power-up text
    this.powerUpText = this.add.text(
      this.sys.game.config.width / 2,
      40,
      '',
      {
        fontFamily: 'Poppins',
        fontSize: '20px',
        color: '#ffffff',
        align: 'center'
      }
    ).setOrigin(0.5);
    this.powerUpText.setVisible(false);
    
    // Create power-up timer bar
    this.powerUpTimer = this.add.rectangle(
      this.sys.game.config.width / 2,
      60,
      296,
      10,
      0x00ff00
    );
    this.powerUpTimer.setVisible(false);
  }

  createPauseMenu() {
    // Create a group for pause menu elements
    this.pauseMenu = this.add.group();
    
    // Semi-transparent background
    const overlay = this.add.rectangle(
      0, 0, 
      this.sys.game.config.width, 
      this.sys.game.config.height, 
      0x000000, 0.7
    );
    overlay.setOrigin(0, 0);
    
    // Pause menu panel
    const panel = this.add.image(
      this.sys.game.config.width / 2, 
      this.sys.game.config.height / 2,
      'panel'
    );
    panel.setDisplaySize(400, 300);
    
    // Pause text
    const pauseText = this.add.text(
      this.sys.game.config.width / 2, 
      this.sys.game.config.height / 2 - 100,
      'PAUSED',
      {
        fontFamily: 'Poppins',
        fontSize: '36px',
        color: '#333333',
        fontStyle: 'bold'
      }
    ).setOrigin(0.5);
    
    // Create buttons
    const resumeButton = createButton({
      scene: this,
      x: this.sys.game.config.width / 2,
      y: this.sys.game.config.height / 2 - 20,
      width: 200,
      height: 50,
      text: 'Resume',
      fontFamily: 'Poppins',
      fontSize: 24,
      texture: 'btn-start',
      sound: 'sfx-button',
      callback: () => this.resumeGame()
    });
    
    const settingsButton = createButton({
      scene: this,
      x: this.sys.game.config.width / 2,
      y: this.sys.game.config.height / 2 + 50,
      width: 200,
      height: 50,
      text: 'Settings',
      fontFamily: 'Poppins',
      fontSize: 24,
      texture: 'btn-settings',
      sound: 'sfx-button',
      callback: () => this.openSettings()
    });
    
    const mainMenuButton = createButton({
      scene: this,
      x: this.sys.game.config.width / 2,
      y: this.sys.game.config.height / 2 + 120,
      width: 200,
      height: 50,
      text: 'Main Menu',
      fontFamily: 'Poppins',
      fontSize: 24,
      texture: 'btn-home',
      sound: 'sfx-button',
      callback: () => this.exitToMainMenu()
    });
    
    // Add all elements to the pause menu group
    this.pauseMenu.add(overlay);
    this.pauseMenu.add(panel);
    this.pauseMenu.add(pauseText);
    this.pauseMenu.add(resumeButton);
    this.pauseMenu.add(settingsButton);
    this.pauseMenu.add(mainMenuButton);
  }

  updateScore(score) {
    this.scoreText.setText(`Score: ${score}`);
  }

  updateDistance(distance) {
    this.distanceText.setText(`Distance: ${distance}m`);
  }

  updateLives(lives) {
    // Clear previous lives
    this.livesGroup.clear(true, true);
    
    // Add life icons
    for (let i = 0; i < lives; i++) {
      const lifeIcon = this.add.image(
        this.sys.game.config.width - 50 - (i * 40), 
        100, 
        'life-icon'
      );
      lifeIcon.setScale(0.7);
      this.livesGroup.add(lifeIcon);
    }
  }

  showPowerUpEffect(powerUpType, duration) {
    // Make power-up indicator visible
    this.powerUpBg.setVisible(true);
    this.powerUpText.setVisible(true);
    this.powerUpTimer.setVisible(true);
    
    // Set text based on power-up type
    let text = '';
    let color = 0x00ff00;
    
    switch (powerUpType) {
      case 'powerup-scroll':
        text = 'Invincibility!';
        color = 0xffff00;
        break;
      case 'powerup-flag':
        text = 'Speed Boost!';
        color = 0xff0000;
        break;
      case 'powerup-support':
        text = 'Extra Life!';
        color = 0x00ff00;
        break;
    }
    
    this.powerUpText.setText(text);
    this.powerUpTimer.fillColor = color;
    
    // Reset width
    this.powerUpTimer.width = 296;
    
    // Animate timer bar
    if (this.timerTween) {
      this.timerTween.stop();
    }
    
    this.timerTween = this.tweens.add({
      targets: this.powerUpTimer,
      width: 0,
      duration: duration,
      ease: 'Linear'
    });
  }

  hidePowerUpEffect() {
    // Hide power-up indicator
    this.powerUpBg.setVisible(false);
    this.powerUpText.setVisible(false);
    this.powerUpTimer.setVisible(false);
    
    // Stop timer animation
    if (this.timerTween) {
      this.timerTween.stop();
    }
  }

  showPauseMenu() {
    this.pauseMenu.setVisible(true);
  }

  hidePauseMenu() {
    this.pauseMenu.setVisible(false);
  }

  resumeGame() {
    this.hidePauseMenu();
    this.events.emit('resume_game');
  }

  openSettings() {
    this.scene.launch('SettingsScene');
  }

  exitToMainMenu() {
    this.events.emit('exit_to_menu');
  }
}