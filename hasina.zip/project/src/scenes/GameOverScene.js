import Phaser from 'phaser';
import { createButton } from '../utils/ui.js';

export class GameOverScene extends Phaser.Scene {
  constructor() {
    super({ key: 'GameOverScene' });
  }

  init(data) {
    this.score = data.score || 0;
    this.distance = data.distance || 0;
  }

  create() {
    // Semi-transparent overlay
    const overlay = this.add.rectangle(0, 0, 
      this.sys.game.config.width, 
      this.sys.game.config.height, 
      0x000000, 0.7);
    overlay.setOrigin(0, 0);
    
    // Game over panel
    const panelWidth = 500;
    const panelHeight = 400;
    const panel = this.add.image(
      this.sys.game.config.width / 2, 
      this.sys.game.config.height / 2,
      'panel'
    );
    panel.setDisplaySize(panelWidth, panelHeight);
    
    // Game over text
    this.add.text(
      this.sys.game.config.width / 2, 
      this.sys.game.config.height / 2 - 150,
      'Game Over',
      {
        fontFamily: 'Poppins',
        fontSize: '40px',
        color: '#ff0000',
        fontStyle: 'bold'
      }
    ).setOrigin(0.5);
    
    // Funny animation message
    this.add.text(
      this.sys.game.config.width / 2, 
      this.sys.game.config.height / 2 - 90,
      'এইবার না পারলেও, আগামীবার অবশ্যই পারব।',
      {
        fontFamily: 'Noto Sans Bengali',
        fontSize: '22px',
        color: '#333333',
        align: 'center',
        wordWrap: { width: panelWidth - 80 }
      }
    ).setOrigin(0.5);
    
    // Add score details
    this.createScoreDisplay();
    
    // Add buttons
    this.createButtons();
    
    // Add character animation
    this.createCharacterAnimation();
  }

  createScoreDisplay() {
    const gameData = this.registry.get('gameData');
    const isHighScore = this.score > gameData.highScore;
    
    // Score title
    this.add.text(
      this.sys.game.config.width / 2, 
      this.sys.game.config.height / 2 - 20,
      'Score',
      {
        fontFamily: 'Poppins',
        fontSize: '28px',
        color: '#333333'
      }
    ).setOrigin(0.5);
    
    // Score value
    const scoreText = this.add.text(
      this.sys.game.config.width / 2, 
      this.sys.game.config.height / 2 + 20,
      this.score.toString(),
      {
        fontFamily: 'Poppins',
        fontSize: '48px',
        color: '#006a4e',
        fontStyle: 'bold'
      }
    ).setOrigin(0.5);
    
    // Distance traveled
    this.add.text(
      this.sys.game.config.width / 2, 
      this.sys.game.config.height / 2 + 70,
      `Distance: ${Math.floor(this.distance)} m`,
      {
        fontFamily: 'Poppins',
        fontSize: '20px',
        color: '#333333'
      }
    ).setOrigin(0.5);
    
    // High score badge if applicable
    if (isHighScore) {
      // Create high score badge
      const badge = this.add.graphics();
      badge.fillStyle(0xf42a41, 1);
      badge.fillRoundedRect(
        this.sys.game.config.width / 2 + 80, 
        this.sys.game.config.height / 2 - 30, 
        140, 40, 10);
      
      this.add.text(
        this.sys.game.config.width / 2 + 150, 
        this.sys.game.config.height / 2 - 10,
        'NEW HIGH SCORE!',
        {
          fontFamily: 'Poppins',
          fontSize: '16px',
          color: '#ffffff',
          fontStyle: 'bold'
        }
      ).setOrigin(0.5);
      
      // Add a pulsing animation to the score
      this.tweens.add({
        targets: scoreText,
        scale: 1.2,
        duration: 500,
        yoyo: true,
        repeat: 3,
        ease: 'Sine.easeInOut'
      });
    }
  }

  createButtons() {
    const buttonConfig = {
      scene: this,
      width: 150,
      height: 50,
      fontFamily: 'Poppins',
      fontSize: 20,
      sound: 'sfx-button'
    };
    
    // Retry button
    createButton({
      ...buttonConfig,
      x: this.sys.game.config.width / 2 - 160,
      y: this.sys.game.config.height / 2 + 150,
      text: 'Retry',
      texture: 'btn-retry',
      callback: () => this.restartGame()
    });
    
    // Home button
    createButton({
      ...buttonConfig,
      x: this.sys.game.config.width / 2,
      y: this.sys.game.config.height / 2 + 150,
      text: 'Home',
      texture: 'btn-home',
      callback: () => this.goToMainMenu()
    });
    
    // Share button
    createButton({
      ...buttonConfig,
      x: this.sys.game.config.width / 2 + 160,
      y: this.sys.game.config.height / 2 + 150,
      text: 'Share',
      texture: 'btn-share',
      callback: () => this.shareScore()
    });
  }

  createCharacterAnimation() {
    // Add a character sprite with idle animation
    const character = this.add.sprite(
      this.sys.game.config.width / 2 - 180, 
      this.sys.game.config.height / 2 - 40,
      'player'
    );
    character.setScale(1.2);
    
    // Play hurt animation
    character.play('hurt');
    
    // Add a recovering animation
    this.tweens.add({
      targets: character,
      y: character.y - 10,
      angle: {from: -5, to: 5},
      duration: 1000,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut'
    });
  }

  restartGame() {
    this.scene.stop();
    this.scene.stop('UIScene');
    this.scene.start('GameScene');
  }

  goToMainMenu() {
    this.scene.stop();
    this.scene.stop('UIScene');
    this.scene.start('MenuScene');
  }

  shareScore() {
    // Create share message
    const shareText = `I scored ${this.score} points and ran ${Math.floor(this.distance)}m in Sheikh Hasina Runner Game! Can you beat my score?`;
    
    // Check if Web Share API is available
    if (navigator.share) {
      navigator.share({
        title: 'Sheikh Hasina Runner Game',
        text: shareText,
        url: window.location.href
      }).catch(err => {
        console.error('Error sharing:', err);
      });
    } else {
      // Fallback - copy to clipboard
      const textArea = document.createElement('textarea');
      textArea.value = shareText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      
      // Show copied message
      const copiedText = this.add.text(
        this.sys.game.config.width / 2,
        this.sys.game.config.height - 70,
        'Score copied to clipboard!',
        {
          fontFamily: 'Poppins',
          fontSize: '16px',
          color: '#ffffff'
        }
      ).setOrigin(0.5);
      
      // Fade out after 2 seconds
      this.tweens.add({
        targets: copiedText,
        alpha: 0,
        delay: 2000,
        duration: 500,
        onComplete: function() {
          copiedText.destroy();
        }
      });
    }
  }
}