import Phaser from 'phaser';

export class PowerUpManager {
  constructor(scene) {
    this.scene = scene;
    
    // Create power-up group
    this.powerUpsGroup = scene.physics.add.group();
    
    // Define power-up types and their properties
    this.powerUpTypes = [
      {
        key: 'powerup-scroll',
        name: 'Constitution Scroll',
        effect: 'invincibility',
        duration: 10000,
        scale: 0.7,
        rarity: 0.3
      },
      {
        key: 'powerup-flag',
        name: 'National Flag',
        effect: 'speedBoost',
        duration: 5000,
        scale: 0.7,
        rarity: 0.5
      },
      {
        key: 'powerup-support',
        name: 'Peoples Support',
        effect: 'extraLife',
        duration: 0,
        scale: 0.7,
        rarity: 0.2
      }
    ];
    
    // Spawn parameters
    this.minSpawnTime = 8000;
    this.maxSpawnTime = 15000;
    this.lastSpawnTime = 0;
    this.spawnTimeRange = this.maxSpawnTime - this.minSpawnTime;
    this.nextSpawnTime = this.getNextSpawnTime();
    
    // Active power-ups
    this.activePowerUps = new Map();
    
    // Power-up movement
    this.powerUpSpeed = 1;
    
    // Scene bounds
    this.rightBound = scene.sys.game.config.width + 100;
    this.minY = scene.sys.game.config.height - 350;
    this.maxY = scene.sys.game.config.height - 150;
  }

  start() {
    // Reset parameters
    this.lastSpawnTime = 0;
    this.nextSpawnTime = this.getNextSpawnTime();
    
    // Clear existing power-ups
    this.powerUpsGroup.clear(true, true);
    
    // Clear active power-ups
    this.activePowerUps.forEach((timer, effect) => {
      timer.remove();
    });
    this.activePowerUps.clear();
  }

  update(speed) {
    // Scale power-up speed with game speed
    this.powerUpSpeed = speed / 500;
    
    // Check if it's time to spawn a new power-up
    if (this.scene.isGameRunning && !this.scene.isPaused) {
      const time = this.scene.time.now;
      if (time > this.lastSpawnTime + this.nextSpawnTime) {
        this.spawnPowerUp();
        this.lastSpawnTime = time;
        this.nextSpawnTime = this.getNextSpawnTime();
      }
    }
    
    // Move power-ups and remove those that have gone off screen
    this.powerUpsGroup.getChildren().forEach(powerUp => {
      // Move power-up to the left
      powerUp.x -= this.powerUpSpeed * this.scene.game.loop.delta * 0.01;
      
      // Add floating effect
      powerUp.y = powerUp.originalY + Math.sin(this.scene.time.now / 300) * 10;
      
      // Remove if off-screen
      if (powerUp.x < -100) {
        powerUp.destroy();
      }
    });
  }

  spawnPowerUp() {
    // Choose a power-up type based on rarity
    const powerUpType = this.choosePowerUpType();
    
    // Random Y position within range
    const y = Phaser.Math.Between(this.minY, this.maxY);
    
    // Create the power-up
    const powerUp = this.powerUpsGroup.create(this.rightBound, y, powerUpType.key);
    
    // Configure power-up
    powerUp.setScale(powerUpType.scale);
    powerUp.originalY = y;
    
    // Add a glow effect
    powerUp.preFX.addGlow(0xffffff, 4, 0, false, 0.1, 16);
    
    // Add floating animation
    this.scene.tweens.add({
      targets: powerUp,
      scale: powerUpType.scale * 1.2,
      duration: 1000,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut'
    });
    
    // Add a collectible hitbox
    powerUp.body.setSize(80, 80);
    powerUp.body.setOffset(20, 20);
    
    return powerUp;
  }

  applyPowerUp(powerUpKey) {
    // Find power-up type from key
    const powerUpType = this.powerUpTypes.find(type => type.key === powerUpKey);
    
    if (!powerUpType) return;
    
    // Apply effect based on type
    switch (powerUpType.effect) {
      case 'invincibility':
        this.applyInvincibility(powerUpType.duration);
        break;
      case 'speedBoost':
        this.applySpeedBoost(powerUpType.duration);
        break;
      case 'extraLife':
        this.applyExtraLife();
        break;
    }
    
    // Update mission progress for collection
    this.updateMissionProgress();
  }

  applyInvincibility(duration) {
    // Make player invincible
    this.scene.player.becomeInvincible(duration);
    
    // Cancel existing timer if present
    if (this.activePowerUps.has('invincibility')) {
      this.activePowerUps.get('invincibility').remove();
    }
    
    // Emit event for UI
    this.scene.events.emit('powerup_activated', 'powerup-scroll', duration);
    
    // Set timer to end effect
    const timer = this.scene.time.delayedCall(duration, () => {
      this.activePowerUps.delete('invincibility');
      this.scene.events.emit('powerup_deactivated', 'invincibility');
    });
    
    // Store active power-up
    this.activePowerUps.set('invincibility', timer);
  }

  applySpeedBoost(duration) {
    // Store original speed
    const originalSpeed = this.scene.speed;
    
    // Boost game speed
    this.scene.speed = Math.min(this.scene.maxSpeed, this.scene.speed * 1.5);
    
    // Cancel existing timer if present
    if (this.activePowerUps.has('speedBoost')) {
      this.activePowerUps.get('speedBoost').remove();
    }
    
    // Emit event for UI
    this.scene.events.emit('powerup_activated', 'powerup-flag', duration);
    
    // Set timer to end effect
    const timer = this.scene.time.delayedCall(duration, () => {
      // Gradually return to normal speed
      this.scene.tweens.add({
        targets: this.scene,
        speed: originalSpeed,
        duration: 1000,
        ease: 'Sine.easeOut'
      });
      this.activePowerUps.delete('speedBoost');
      this.scene.events.emit('powerup_deactivated', 'speedBoost');
    });
    
    // Store active power-up
    this.activePowerUps.set('speedBoost', timer);
  }

  applyExtraLife() {
    // Add extra life if below maximum
    if (this.scene.player.lives < 3) {
      this.scene.player.lives++;
      this.scene.events.emit('lives_updated', this.scene.player.lives);
    } else {
      // If already at max lives, give points instead
      this.scene.scoreManager.addScore(50);
    }
    
    // Show brief notification
    this.scene.events.emit('powerup_activated', 'powerup-support', 2000);
    
    // Set timer to hide notification
    const timer = this.scene.time.delayedCall(2000, () => {
      this.scene.events.emit('powerup_deactivated', 'extraLife');
    });
  }

  choosePowerUpType() {
    // Calculate total rarity
    const totalRarity = this.powerUpTypes.reduce((sum, type) => sum + type.rarity, 0);
    
    // Pick a random point in the rarity range
    let randomPoint = Math.random() * totalRarity;
    
    // Find which power-up type this point corresponds to
    for (const powerUpType of this.powerUpTypes) {
      randomPoint -= powerUpType.rarity;
      if (randomPoint <= 0) {
        return powerUpType;
      }
    }
    
    // Fallback to first type
    return this.powerUpTypes[0];
  }

  getNextSpawnTime() {
    return this.minSpawnTime + Math.random() * this.spawnTimeRange;
  }

  updateMissionProgress() {
    const gameData = this.scene.registry.get('gameData');
    
    // Update collection mission
    const collectMission = gameData.missions.daily.find(m => m.type === 'collect');
    if (collectMission && !collectMission.completed) {
      collectMission.progress += 1;
      if (collectMission.progress >= collectMission.target) {
        collectMission.completed = true;
      }
      
      // Save updated mission progress
      this.scene.registry.set('gameData', gameData);
      localStorage.setItem('sheikhhashinarunner_data', JSON.stringify(gameData));
    }
  }
}