import Phaser from 'phaser';

export class ObstacleManager {
  constructor(scene) {
    this.scene = scene;
    
    // Create obstacle group
    this.obstaclesGroup = scene.physics.add.group();
    
    // Define obstacle types and their properties
    this.obstacleTypes = [
      {
        key: 'obstacle-files',
        name: 'Corruption Files',
        jumpOver: true,
        slideUnder: false,
        scale: 0.8,
        hitboxWidth: 80,
        hitboxHeight: 90,
        offsetX: 10,
        offsetY: 10,
        frequency: 3
      },
      {
        key: 'obstacle-crowd',
        name: 'Protestors',
        jumpOver: false,
        slideUnder: true,
        scale: 0.9,
        hitboxWidth: 100,
        hitboxHeight: 80,
        offsetX: 10,
        offsetY: 20,
        frequency: 2
      },
      {
        key: 'obstacle-drone',
        name: 'Fake News Drone',
        jumpOver: true,
        slideUnder: false,
        scale: 0.7,
        hitboxWidth: 70,
        hitboxHeight: 50,
        offsetX: 15,
        offsetY: 15,
        frequency: 2,
        flying: true
      },
      {
        key: 'obstacle-camera',
        name: 'Media Camera',
        jumpOver: true,
        slideUnder: false,
        scale: 0.7,
        hitboxWidth: 60,
        hitboxHeight: 60,
        offsetX: 20,
        offsetY: 20,
        frequency: 1
      },
      {
        key: 'obstacle-screen',
        name: 'Fake News Screen',
        jumpOver: false,
        slideUnder: true,
        scale: 0.8,
        hitboxWidth: 90,
        hitboxHeight: 100,
        offsetX: 5,
        offsetY: 5,
        frequency: 1
      }
    ];
    
    // Spawn parameters
    this.minSpawnTime = 1200;
    this.maxSpawnTime = 3000;
    this.lastSpawnTime = 0;
    this.spawnTimeRange = this.maxSpawnTime - this.minSpawnTime;
    this.nextSpawnTime = this.getNextSpawnTime();
    
    // Difficulty parameters
    this.difficulty = 1;
    this.maxDifficulty = 5;
    this.obstacleSpeed = 1;
    
    // Scene bounds
    this.rightBound = scene.sys.game.config.width + 100;
    this.groundY = scene.sys.game.config.height - 130;
    this.flyingY = scene.sys.game.config.height - 300;
  }

  start() {
    // Reset parameters
    this.difficulty = 1;
    this.obstacleSpeed = 1;
    this.lastSpawnTime = 0;
    this.nextSpawnTime = this.getNextSpawnTime();
    
    // Clear existing obstacles
    this.obstaclesGroup.clear(true, true);
  }

  update(speed) {
    // Scale obstacle speed with game speed
    this.obstacleSpeed = speed / 500;
    
    // Scale difficulty with speed
    this.difficulty = Math.min(this.maxDifficulty, 1 + (speed - 500) / 200);
    
    // Adjust spawn time range based on difficulty
    this.minSpawnTime = Math.max(800, 1200 - (this.difficulty - 1) * 100);
    this.maxSpawnTime = Math.max(1500, 3000 - (this.difficulty - 1) * 300);
    this.spawnTimeRange = this.maxSpawnTime - this.minSpawnTime;
    
    // Check if it's time to spawn a new obstacle
    if (this.scene.isGameRunning && !this.scene.isPaused) {
      const time = this.scene.time.now;
      if (time > this.lastSpawnTime + this.nextSpawnTime) {
        this.spawnObstacle();
        this.lastSpawnTime = time;
        this.nextSpawnTime = this.getNextSpawnTime();
      }
    }
    
    // Remove obstacles that have gone off screen
    this.obstaclesGroup.getChildren().forEach(obstacle => {
      // Move obstacle to the left
      obstacle.x -= this.obstacleSpeed * this.scene.game.loop.delta * 0.01;
      
      // Remove if off-screen
      if (obstacle.x < -100) {
        obstacle.destroy();
        
        // Add to score for successfully avoiding an obstacle
        if (this.scene.scoreManager) {
          this.scene.scoreManager.addScore(10);
        }
      }
    });
  }

  spawnObstacle() {
    // Choose an obstacle type based on frequency weighting
    const obstacleType = this.chooseObstacleType();
    
    // Determine Y position (flying or ground)
    const y = obstacleType.flying ? this.flyingY : this.groundY;
    
    // Create the obstacle
    const obstacle = this.obstaclesGroup.create(this.rightBound, y, obstacleType.key);
    
    // Configure obstacle
    obstacle.setOrigin(0.5, 1);
    obstacle.setScale(obstacleType.scale);
    
    // Configure hitbox
    obstacle.body.setSize(obstacleType.hitboxWidth, obstacleType.hitboxHeight);
    obstacle.body.setOffset(obstacleType.offsetX, obstacleType.offsetY);
    
    // Store obstacle type properties with the sprite
    obstacle.obstacleType = obstacleType;
    
    // Add obstacles in patterns at higher difficulties
    if (this.difficulty >= 3 && Math.random() < 0.3) {
      this.createObstaclePattern(obstacleType);
    }
    
    return obstacle;
  }

  createObstaclePattern(firstObstacleType) {
    // Simple patterns based on difficulty
    if (this.difficulty >= 4 && Math.random() < 0.5) {
      // Double obstacle pattern (one to jump, one to slide)
      const secondType = this.obstacleTypes.find(type => 
        type.jumpOver !== firstObstacleType.jumpOver
      );
      
      if (secondType) {
        // Spawn second obstacle with delay
        this.scene.time.delayedCall(500, () => {
          const y = secondType.flying ? this.flyingY : this.groundY;
          const obstacle = this.obstaclesGroup.create(this.rightBound, y, secondType.key);
          
          obstacle.setOrigin(0.5, 1);
          obstacle.setScale(secondType.scale);
          
          obstacle.body.setSize(secondType.hitboxWidth, secondType.hitboxHeight);
          obstacle.body.setOffset(secondType.offsetX, secondType.offsetY);
          
          obstacle.obstacleType = secondType;
        });
      }
    } else {
      // Double same-type obstacle pattern
      this.scene.time.delayedCall(600, () => {
        const y = firstObstacleType.flying ? this.flyingY : this.groundY;
        const obstacle = this.obstaclesGroup.create(this.rightBound, y, firstObstacleType.key);
        
        obstacle.setOrigin(0.5, 1);
        obstacle.setScale(firstObstacleType.scale);
        
        obstacle.body.setSize(firstObstacleType.hitboxWidth, firstObstacleType.hitboxHeight);
        obstacle.body.setOffset(firstObstacleType.offsetX, firstObstacleType.offsetY);
        
        obstacle.obstacleType = firstObstacleType;
      });
    }
  }

  chooseObstacleType() {
    // Calculate total frequency
    const totalFrequency = this.obstacleTypes.reduce((sum, type) => sum + type.frequency, 0);
    
    // Pick a random point in the frequency range
    let randomPoint = Math.random() * totalFrequency;
    
    // Find which obstacle type this point corresponds to
    for (const obstacleType of this.obstacleTypes) {
      randomPoint -= obstacleType.frequency;
      if (randomPoint <= 0) {
        return obstacleType;
      }
    }
    
    // Fallback to first type
    return this.obstacleTypes[0];
  }

  getNextSpawnTime() {
    return this.minSpawnTime + Math.random() * this.spawnTimeRange;
  }
}