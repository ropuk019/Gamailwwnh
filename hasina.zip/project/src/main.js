import Phaser from 'phaser';
import { BootScene } from './scenes/BootScene.js';
import { PreloadScene } from './scenes/PreloadScene.js';
import { MenuScene } from './scenes/MenuScene.js';
import { GameScene } from './scenes/GameScene.js';
import { GameOverScene } from './scenes/GameOverScene.js';
import { SettingsScene } from './scenes/SettingsScene.js';
import { LeaderboardScene } from './scenes/LeaderboardScene.js';
import { MissionsScene } from './scenes/MissionsScene.js';
import { CharacterScene } from './scenes/CharacterScene.js';
import { UIScene } from './scenes/UIScene.js';

// Game configuration
const config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  parent: 'game-container',
  backgroundColor: '#f5f5f5',
  physics: {
    default: 'arcade',
    arcade: {
      gravity: { y: 1500 },
      debug: false
    }
  },
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH
  },
  scene: [
    BootScene,
    PreloadScene,
    MenuScene,
    GameScene,
    GameOverScene,
    SettingsScene,
    LeaderboardScene,
    MissionsScene,
    CharacterScene,
    UIScene
  ]
};

// Create and start the game
const game = new Phaser.Game(config);

// Expose game to global scope for debugging
window.game = game;

// Handle visibility change to pause/resume game
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    game.scene.getScenes(true).forEach(scene => {
      if (scene.scene.key === 'GameScene' && scene.scene.isActive()) {
        scene.pauseGame();
      }
    });
  }
});

// Add event listeners for fullscreen toggle
document.addEventListener('keydown', (event) => {
  if (event.key === 'f') {
    toggleFullscreen();
  }
});

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen().catch(err => {
      console.error(`Error attempting to enable fullscreen: ${err.message}`);
    });
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  }
}