import Phaser from 'phaser';

export class Player {
  constructor(scene, x, y) {
    this.scene = scene;
    
    // Create player sprite
    this.sprite = scene.physics.add.sprite(x, y, 'player');
    this.sprite.setScale(0.8);
    this.sprite.setCollideWorldBounds(true);
    this.sprite.body.setSize(80, 120);
    this.sprite.body.setOffset(24, 8);
    
    // Player state
    this.isJumping = false;
    this.isSliding = false;
    this.canJump = true;
    this.isInvincible = false;
    this.lives = 3;
    
    // Initialize animations
    this.sprite.anims.play('run', true);
    
    // Set up input handlers
    this.setupInputHandlers();
  }

  setupInputHandlers() {
    // Keyboard controls
    this.scene.input.keyboard.on('keydown-SPACE', () => this.jump());
    this.scene.input.keyboard.on('keydown-DOWN', () => this.slide());
  }

  update() {
    const onGround = this.sprite.body.touching.down || this.sprite.body.blocked.down;
    
    // Reset jump ability when touching ground
    if (onGround && this.isJumping) {
      this.isJumping = false;
      this.canJump = true;
      if (!this.isSliding) {
        this.sprite.anims.play('run', true);
      }
    }
    
    // End slide if animation is complete
    if (this.isSliding && !this.sprite.anims.isPlaying) {
      this.endSlide();
    }
  }

  jump() {
    // Only allow jump if not already jumping and not sliding
    if (!this.canJump || this.isSliding) return;
    
    this.isJumping = true;
    this.canJump = false;
    
    // Apply jump velocity
    this.sprite.setVelocityY(-800);
    
    // Play jump animation
    this.sprite.anims.play('jump');
    
    // Play jump sound if enabled
    if (this.scene.registry.get('soundEnabled')) {
      this.scene.sound.play('sfx-jump');
    }
  }

  slide() {
    // Only allow slide if not already sliding and on the ground
    if (this.isSliding || (this.isJumping && !this.sprite.body.touching.down)) return;
    
    this.isSliding = true;
    
    // Adjust hitbox for sliding
    this.sprite.body.setSize(80, 60);
    this.sprite.body.setOffset(24, 68);
    
    // Play slide animation
    this.sprite.anims.play('slide');
    
    // Play slide sound if enabled
    if (this.scene.registry.get('soundEnabled')) {
      this.scene.sound.play('sfx-slide');
    }
    
    // Set timeout to end slide
    this.scene.time.delayedCall(500, () => {
      this.endSlide();
    });
  }

  endSlide() {
    if (!this.isSliding) return;
    
    this.isSliding = false;
    
    // Reset hitbox
    this.sprite.body.setSize(80, 120);
    this.sprite.body.setOffset(24, 8);
    
    // Resume running animation if on ground
    if (!this.isJumping) {
      this.sprite.anims.play('run', true);
    }
  }

  becomeInvincible(duration) {
    this.isInvincible = true;
    
    // Visual effect for invincibility
    this.scene.tweens.add({
      targets: this.sprite,
      alpha: 0.5,
      duration: 100,
      yoyo: true,
      repeat: duration / 200,
      onComplete: () => {
        this.sprite.alpha = 1;
        this.isInvincible = false;
      }
    });
  }

  loseLife() {
    this.lives--;
    
    // Emit event to update UI
    this.scene.events.emit('lives_updated', this.lives);
    
    // Play hurt animation
    this.sprite.anims.play('hurt');
    
    // Resume running animation after hurt animation completes
    this.scene.time.delayedCall(500, () => {
      if (!this.isJumping && !this.isSliding) {
        this.sprite.anims.play('run', true);
      }
    });
  }

  reset() {
    this.lives = 3;
    this.isJumping = false;
    this.isSliding = false;
    this.canJump = true;
    this.isInvincible = false;
    
    // Reset body size
    this.sprite.body.setSize(80, 120);
    this.sprite.body.setOffset(24, 8);
    
    // Reset velocity
    this.sprite.setVelocity(0, 0);
    
    // Play run animation
    this.sprite.anims.play('run', true);
    
    // Emit lives updated event
    this.scene.events.emit('lives_updated', this.lives);
  }
}